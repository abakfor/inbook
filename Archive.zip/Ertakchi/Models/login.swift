//
//  login.swift
//  Ertakchi
//
//

import Foundation

struct LoginModel: Codable {
    let token: String?
}
