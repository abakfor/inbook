//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import <google/cloud/speech/v1p1beta1/CloudSpeech.pbobjc.h>
#import <google/cloud/speech/v1p1beta1/CloudSpeech.pbrpc.h>
